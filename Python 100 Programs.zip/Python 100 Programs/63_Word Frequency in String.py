# Word Frequency in String: Count occurrences of each word in a string using .split().

text = input("Enter a string: ")

words = text.split()
frequency = {}

for word in words:
    if word in frequency:
        frequency[word] += 1
    else:
        frequency[word] = 1

print("Word Frequency:", frequency)