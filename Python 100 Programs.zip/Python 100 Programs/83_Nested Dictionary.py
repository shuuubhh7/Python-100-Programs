# Nested Dictionary: Create a nested dictionary for employee records and access nested fields.

employees = {
    "employee1": {
        "name": "Yash",
        "age": 18,
        "department": "IT"
    },
    "employee2": {
        "name": "Rahul",
        "age": 20,
        "department": "HR"
    }
}

print("Employee 1 Name:", employees["employee1"]["name"])
print("Employee 1 Department:", employees["employee1"]["department"])
print("Employee 2 Name:", employees["employee2"]["name"])