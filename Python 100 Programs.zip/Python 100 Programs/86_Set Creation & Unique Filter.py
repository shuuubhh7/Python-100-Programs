# Set Creation & Unique Filter: Convert a list with duplicates into a set to extract unique elements.

numbers = [10, 20, 10, 30, 20, 40, 30]

unique_numbers = set(numbers)

print("Original list:", numbers)
print("Unique elements:", unique_numbers)