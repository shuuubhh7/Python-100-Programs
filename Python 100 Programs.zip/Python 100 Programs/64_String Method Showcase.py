# String Method Showcase: Implement .strip(), .replace(), .find(), .startswith(), and .endswith().

text = "  Hello Python  "

print("strip:", text.strip())
print("replace:", text.replace("Python", "World"))
print("find:", text.find("Python"))
print("startswith:", text.strip().startswith("Hello"))
print("endswith:", text.strip().endswith("Python"))