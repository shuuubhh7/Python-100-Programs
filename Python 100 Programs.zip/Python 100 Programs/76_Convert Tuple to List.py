# Convert Tuple to List: Convert a tuple to a list to modify an element, then convert it back.
numbers = (10, 20, 30, 40)

print("Original tuple:", numbers)

my_list = list(numbers)

my_list[1] = 100

numbers = tuple(my_list)

print("Modified tuple:", numbers)