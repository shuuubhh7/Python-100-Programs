# Student Marks Lookup: Create a dictionary storing student names and marks; retrieve marks given a name.

students = {
    "Yatharth": 90,
    "Rahul": 85,
    "Aman": 80
}

name = input("Enter student name: ")

if name in students:
    print("Marks =", students[name])
else:
    print("Student not found")