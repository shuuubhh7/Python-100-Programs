# CSV File Parser: Read a simple comma-separated values (CSV) file using file operations and parse fields manually.

from pathlib import Path

students_file = Path(__file__).parent / "students.csv"

with students_file.open("r", encoding="utf-8") as file:
    for line in file:
        fields = line.strip().split(",")

        name = fields[0]
        marks = fields[1]
        subject = fields[2]

        print("Name:", name)
        print("Marks:", marks)
        print("Subject:", subject)
        print()
