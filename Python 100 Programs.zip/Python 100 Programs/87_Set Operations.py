#  Set Operations: Perform Union, Intersection, Difference, and Symmetric Difference on two sets.

A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

print("Union:", A | B)
print("Intersection:", A & B)
print("Difference:", A - B)
print("Symmetric Difference:", A ^ B)