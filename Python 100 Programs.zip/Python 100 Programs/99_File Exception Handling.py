#  File Exception Handling: Wrap file opening logic in try-except blocks to handle FileNotFoundError gracefully.

filename = input("Enter file name: ")

try:
    with open(filename, "r") as file:
        content = file.read()
        print(content)

except FileNotFoundError:
    print("Error: File not found.")