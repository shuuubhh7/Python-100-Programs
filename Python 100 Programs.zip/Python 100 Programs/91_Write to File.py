# Write to File: Create a new text file data.txt and write three lines of text into it.

with open("data.txt", "w") as file:
    file.write("Hello Python\n")
    file.write("This is a text file.\n")
    file.write("Learning file handling.")

print("Data written successfully.")