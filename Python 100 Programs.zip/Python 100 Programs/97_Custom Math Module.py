# Custom Math Module: Write a module my_math.py containing custom arithmetic functions and import it into another script.

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b



