#  Read File Content: Open data.txt and display its content line-by-line using a for loop.

with open("data.txt", "r") as file:
    for line in file:
        print(line.strip())