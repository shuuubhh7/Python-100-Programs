# Element Occurrence Count: Find the frequency of a specific element in a tuple using .count().

numbers = (10, 20, 10, 30, 10, 40)

element = int(input("Enter element to count: "))

count = numbers.count(element)

print("Frequency =", count)