# List Creation & Indexing: Create a list of integers, access elements using positive/negative indexing.

numbers = [10, 20, 30, 40, 50]

print("List:", numbers)
print("First element:", numbers[0])
print("Third element:", numbers[2])
print("Last element:", numbers[-1])
print("Second last element:", numbers[-2])