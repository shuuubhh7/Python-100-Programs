# Tuple Packing & Unpacking: Pack multiple variables into a tuple and unpack them into distinct variables.

name = "Yatharth"
age = 18
course = "Python"

student = name, age, course

print("Packed tuple:", student)

a, b, c = student

print("Name:", a)
print("Age:", b)
print("Course:", c)