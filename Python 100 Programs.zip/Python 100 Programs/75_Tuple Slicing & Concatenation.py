# Tuple Slicing & Concatenation: Slice a tuple and concatenate two tuples into a new one.

tuple1 = (1, 2, 3, 4, 5)
tuple2 = (6, 7, 8)

print("Sliced tuple:", tuple1[1:4])

result = tuple1 + tuple2

print("Concatenated tuple:", result)