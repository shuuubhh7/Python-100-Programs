# List Reverse: Reverse a list in-place and using slicing.

numbers = [1, 2, 3, 4, 5]

numbers.reverse()
print("In-place reverse:", numbers)

numbers = [1, 2, 3, 4, 5]
print("Slicing reverse:", numbers[::-1])