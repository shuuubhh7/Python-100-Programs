# File Reverse Output: Read a file and write its lines in reverse order into a new file.

with open("source.txt", "r") as file:
    lines = file.readlines()

with open("reverse.txt", "w") as file:
    for line in reversed(lines):
        file.write(line)

print("Lines written in reverse order.")