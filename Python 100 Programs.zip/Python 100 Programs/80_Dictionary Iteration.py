# Dictionary Iteration: Iterate through keys, values, and key-value pairs using .keys(), .values(), and .items().

student = {
    "name": "Yatharth",
    "age": 18,
    "marks": 90
}

print("Keys:")

for key in student.keys():
    print(key)

print("Values:")

for value in student.values():
    print(value)

print("Key-Value pairs:")

for key, value in student.items():
    print(key, ":", value)