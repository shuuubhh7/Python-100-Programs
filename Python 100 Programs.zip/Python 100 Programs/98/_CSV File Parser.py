# CSV File Parser
from pathlib import Path

students_file = Path(__file__).parent / "students.csv"

with students_file.open("r", encoding="utf-8") as file:
    for line in file:
        name, marks, subject = line.strip().split(",")
        print("Name:", name)
        print("Marks:", marks)
        print("Subject:", subject)
        print()
