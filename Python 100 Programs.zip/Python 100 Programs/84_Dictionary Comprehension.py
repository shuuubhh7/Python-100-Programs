# Dictionary Comprehension: Generate a dictionary mapping numbers (1–10) to their cubes.

cubes = {x: x ** 3 for x in range(1, 11)}

print(cubes)