#  Subset and Superset Check: Test if Set A is a subset or superset of Set B.

A = {1, 2, 3}
B = {1, 2, 3, 4, 5}

print("A is subset of B:", A.issubset(B))
print("B is superset of A:", B.issuperset(A))