#  Search Word in File: Search for a specific target word inside a text file and print the line numbers where it occurs.

target = input("Enter word to search: ")

with open("data.txt", "r") as file:
    found = False

    for line_number, line in enumerate(file, start=1):
        if target.lower() in line.lower():
            print("Word found on line", line_number)
            found = True

if not found:
    print("Word not found")