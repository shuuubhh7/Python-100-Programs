# Title Case Converter: Convert a lower-case string to title case without using .title(). 

text = input("Enter a string: ")

words = text.split()
result = ""

for word in words:
    result += word[0].upper() + word[1:].lower() + " "

print("Title Case =", result.strip())