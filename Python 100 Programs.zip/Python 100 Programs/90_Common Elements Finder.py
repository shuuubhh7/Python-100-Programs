# Common Elements Finder: Find common elements between three distinct lists using set operations.

list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 5, 6, 7]
list3 = [4, 5, 8, 9]

common = set(list1) & set(list2) & set(list3)

print("Common elements:", common)