#  Set Modification: Add elements using .add() and remove elements safely using .discard().

numbers = {10, 20, 30}

numbers.add(40)
numbers.add(50)

numbers.discard(20)
numbers.discard(100)

print("Modified set:", numbers)