# Second Largest Element: Find the second largest number in an unsorted list.

numbers = [10, 50, 30, 40, 20]

largest = numbers[0]
second = None

for num in numbers:
    if num > largest:
        second = largest
        largest = num
    elif num != largest and (second is None or num > second):
        second = num

print("Second largest =", second)