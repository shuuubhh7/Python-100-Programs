# Vowel or Consonant: Check if an input character is a vowel, consonant, or non-alphabetic character.

ch = input("Enter a character: ")

if ch.isalpha():
    if ch.lower() in "aeiou":
        print("Vowel")
    else:
        print("Consonant")
else:
    print("Non-alphabetic character")