#  Append to File: Append new user-entered records to an existing text file.

record = input("Enter a record: ")

with open("data.txt", "a") as file:
    file.write(record + "\n")

print("Record added successfully.")