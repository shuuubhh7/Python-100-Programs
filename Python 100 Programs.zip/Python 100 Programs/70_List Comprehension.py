# List Comprehension: Create a new list containing squares of even numbers from a given list.

numbers = [1, 2, 3, 4, 5, 6, 7, 8]

squares = [x * x for x in numbers if x % 2 == 0]

print("Squares of even numbers:", squares)