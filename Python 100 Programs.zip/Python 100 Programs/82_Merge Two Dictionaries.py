# Merge Two Dictionaries: Combine two dictionaries using .update() and dictionary unpacking (**).

dict1 = {"a": 10, "b": 20}
dict2 = {"c": 30, "d": 40}

# Using update()
merged1 = dict1.copy()
merged1.update(dict2)

# Using dictionary unpacking
merged2 = {**dict1, **dict2}

print("Using update():", merged1)
print("Using unpacking:", merged2)