# Min, Max, and Average: Find the minimum, maximum, sum, and average of a list without using built-in functions.

numbers = [10, 20, 30, 40, 50]

minimum = numbers[0]
maximum = numbers[0]
total = 0
count = 0

for num in numbers:
    if num < minimum:
        minimum = num

    if num > maximum:
        maximum = num

    total += num
    count += 1

average = total / count

print("Minimum =", minimum)
print("Maximum =", maximum)
print("Sum =", total)
print("Average =", average)