# Palindrome String: Check if a given string is a palindrome.
text = input("Enter a string: ")

if text == text[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")