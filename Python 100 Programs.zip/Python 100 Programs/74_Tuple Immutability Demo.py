# Tuple Immutability Demo: Demonstrate tuple immutability and handle the resulting TypeError.

numbers = (10, 20, 30)

print("Original tuple:", numbers)

try:
    numbers[0] = 100
except TypeError:
    print("Error: Tuple cannot be changed")