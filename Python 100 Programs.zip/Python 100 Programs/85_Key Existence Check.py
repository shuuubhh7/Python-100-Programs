# Key Existence Check: Check whether a key exists in a dictionary using the in operator.

student = {
    "name": "Yatharth",
    "age": 18,
    "marks": 90
}

key = input("Enter key to search: ")

if key in student:
    print("Key exists")
else:
    print("Key does not exist")