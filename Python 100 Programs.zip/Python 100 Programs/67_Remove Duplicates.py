#  Remove Duplicates: Remove duplicate elements from a list while preserving order.

numbers = [10, 20, 10, 30, 20, 40, 30]

new_list = []

for num in numbers:
    if num not in new_list:
        new_list.append(num)

print("Original List:", numbers)
print("After removing duplicates:", new_list)