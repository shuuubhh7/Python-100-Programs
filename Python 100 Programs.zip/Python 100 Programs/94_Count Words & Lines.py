# Count Words & Lines: Read a text file and calculate the total number of lines, words, and characters.

with open("data.txt", "r") as file:
    content = file.read()

lines = content.splitlines()
words = content.split()
characters = len(content)

print("Number of lines =", len(lines))
print("Number of words =", len(words))
print("Number of characters =", characters)