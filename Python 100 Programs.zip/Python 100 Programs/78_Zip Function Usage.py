# Zip Function Usage: Combine two lists into a list of tuples using zip().

names = ["Yatharth", "Rahul", "Aman"]
marks = [90, 85, 80]

result = list(zip(names, marks))

print("Combined list:", result)