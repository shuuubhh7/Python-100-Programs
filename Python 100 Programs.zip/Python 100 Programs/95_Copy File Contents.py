# Copy File Contents: Read content from source.txt and write it to destination.txt.
# 95. Copy File Contents

from pathlib import Path

folder = Path(__file__).parent
source_file = folder / "source.txt"
destination_file = folder / "destination.txt"

with source_file.open("r", encoding="utf-8") as source:
    content = source.read()

with destination_file.open("w", encoding="utf-8") as destination:
    destination.write(content)

print("File contents copied successfully!")
