# Anagram Checker: Determine if two input strings are anagrams of each other.

a = input("Enter first string: ")
b = input("Enter second string: ")

a = a.replace(" ", "").lower()
b = b.replace(" ", "").lower()

if sorted(a) == sorted(b):
    print("Anagram")
else:
    print("Not Anagram")